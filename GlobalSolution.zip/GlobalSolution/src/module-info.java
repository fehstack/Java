/**
 * 
 */
/**
 * @author fesantiago
 *
 */
module GlobalSolution {
	requires java.desktop;
}