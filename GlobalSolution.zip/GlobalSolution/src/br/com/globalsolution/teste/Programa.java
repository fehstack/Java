package br.com.globalsolution.teste;

import javax.swing.JOptionPane;

import br.com.globalsulotion.beans.Drone;
import br.com.globalsulotion.beans.Emergencia;
import br.com.globalsulotion.beans.Local;
import br.com.globalsulotion.beans.Usuario;

public class Programa {

	public static void main(String[] args) {
		
		Drone drone = new Drone();
		Local local = new Local();
		Emergencia emergencia = new Emergencia();
		Usuario usuario = new Usuario();
		
		
		
		usuario.setQuantidadePessoas(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade pessoas")));
		usuario.setNome(JOptionPane.showInputDialog("Digite o(s) nome(s): "));
		usuario.setIdade(Integer.parseInt(JOptionPane.showInputDialog("Digite a(s) idade(s): ")));
		drone.setTipo(JOptionPane.showInputDialog("Digite o tipo de drone desejado: Simples ou Multi Equipado "));
		drone.setQuantidade(Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade drone desejada")));
		drone.setTempo_resposta(Double.parseDouble(JOptionPane.showInputDialog("Digite o tempo minimo de resposta (minutos)")));
		local.setCEP(Integer.parseInt(JOptionPane.showInputDialog("Digite seu CEP")));
		local.setCidade(JOptionPane.showInputDialog("Digite sua cidade"));
		local.setEstado(JOptionPane.showInputDialog("Digite seu Estado"));
		emergencia.setDistancia(Double.parseDouble(JOptionPane.showInputDialog("Digite a distancia da cidade mais proxima(km)")));
		emergencia.setGravidade(Integer.parseInt(JOptionPane.showInputDialog("Em caso de acidente, digite de 0 a 10 a gravidade da situação")));
		emergencia.setProduto(JOptionPane.showInputDialog("Qual produto de seu interesse? 1- Vacinas, 2 - Primeiros Socorros, 3 - Outros"));
		
		
		System.out.println("\n" + "A quantidade de pessoas é: " + usuario.getQuantidadePessoas() + "\n" + "Nome(s): " + usuario.getNome() + "\n" + "A idade do(s) usuario(s) é: " +  usuario.getIdade() 
							+ " anos" + "\n" + "O tipo de drone desejado é: " + drone.getTipo() + "\n" + "A quantidade de drones é: " + drone.getQuantidade() 
							+ "\n" + "O tempo de resposta desejado é: " + drone.getTempo_resposta() + " minutos" + "\n" + "O CEP é: " + local.getCEP() 
							+ "\n" + "A cidade é: " + local.getCidade() + "\n" + "O estado é: " + local.getEstado() + "\n" + "A distancia da cidade mais proxima é: "
							+ emergencia.getDistancia() + " km" + "\n" + "A gravidade da situação é: " + emergencia.getGravidade() + "\n" 
							+ "O produto desejado é: " + emergencia.getProduto());

	}

}
