package br.com.globalsulotion.beans;

public class Drone {
	
	private String tipo;
	private int quantidade;
	private double tempo_resposta;
	
	
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public double getTempo_resposta() {
		return tempo_resposta;
	}
	public void setTempo_resposta(double tempo_resposta) {
		this.tempo_resposta = tempo_resposta;
	}
	
	public Drone() {
	}
	

}
