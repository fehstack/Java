package br.com.globalsulotion.beans;

public class Emergencia {
	
	private int gravidade;
	private double distancia;
	private String produto;
	
	public Emergencia() {
		
	}
	
	
	public int getGravidade() {
		return gravidade;
	}
	public void setGravidade(int gravidade) {
		this.gravidade = gravidade;
	}
	public double getDistancia() {
		return distancia;
	}
	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	
	

}
