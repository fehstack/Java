package br.com.globalsulotion.beans;

public class Local {

	private int CEP;
	private String Cidade;
	private String Estado;
	
	
	public int getCEP() {
		return CEP;
	}
	public void setCEP(int cEP) {
		CEP = cEP;
	}
	public String getCidade() {
		return Cidade;
	}
	public void setCidade(String cidade) {
		Cidade = cidade;
	}
	public String getEstado() {
		return Estado;
	}
	public void setEstado(String estado) {
		Estado = estado;
	}
	
	public Local() {}
	

	
	
}
