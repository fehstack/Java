package br.com.globalsulotion.beans;

public class Usuario {
	
	private int QuantidadePessoas;
	private String Nome;
	private int idade;
	
	
	
	public Usuario() {}
	
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public int getQuantidadePessoas() {
		return QuantidadePessoas;
	}
	public void setQuantidadePessoas(int quantidadePessoas) {
		QuantidadePessoas = quantidadePessoas;
	}

}
